<?php $__env->startSection('styles'); ?>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/selects/select2-bootstrap.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('parentPageTitle', 'Project'); ?>
<?php $__env->startSection('title', 'Project Management'); ?>


<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-lg-12 col-md-12 bg-transparent">
        <h3><?php echo e($project->project_name); ?> <br> <small><code class="highlighter-rouge"><?php echo e($project->project_status); ?></code></small> <button type="button" name="button" class="btn btn-primary" data-toggle="modal" data-target="#status">Update Status</button></h3>

        <div class="modal fade launch-pricing-modal" id="status" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h6>Update Status</h6>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                    </div>
                    <div class="modal-body pricing_page text-justify pt-4 mb-4">
                      <form  action="<?php echo e(url('update-status/'.$project->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row clearfix">
                            <div class="col-12">
                                <div class="demo-masked-input">
                                    <div class="row clearfix">
                                        <div class="form-group col-lg-12 col-md-12">
                                            <b>Status</b>
                                            <div class="input-group mb-3">
                                            <select class="form-control" name="status">
                                              <option value="Define Problem">Define Problem</option>
                                              <option value="Ideation">Ideation</option>
                                              <option value="On Development">On Development</option>
                                              <option value="Implementation">Implementation</option>
                                            </select>
                                            </div>
                                            <button type="submit" class="btn btn-primary"> <i class="icon-plus"></i> Update </button>
                                        </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                      </form>
                    </div>
                </div>
            </div>

        <?php if($message = Session::get('success')): ?>
          <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
              <strong><?php echo e($message); ?></strong>
          </div>
        <?php endif; ?>

        <?php if($message = Session::get('error')): ?>
          <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
          </div>
        <?php endif; ?>
        <div class="header text-right">
            <a href="/project/myproject" class="btn btn-success fa fa-arrow-left" title="Back"> </a>
        </div>
        <div class="card bg-transparent">
            <div class="body bg-transparent">
                <ul class="nav nav-tabs">
                    <li class="nav-item "><a class="nav-link active show text-info" data-toggle="tab" href="#Info-withicon"><i class="fa fa-info"></i> Info</a></li>
                    <!-- <li class="nav-item"><a class="nav-link text-info" data-toggle="tab" href="#Info-withicon"><i class="fa fa-list-ol"></i> To Do List</a></li>
                    <li class="nav-item"><a class="nav-link text-info" data-toggle="tab" href="#Info-withicon"><i class="fa fa-bars"></i> Backlog</a></li>
                    <li class="nav-item"><a class="nav-link text-info" data-toggle="tab" href="#Info-withicon"><i class="fa fa-tasks"></i> Sprints</a></li>
                    <li class="nav-item"><a class="nav-link text-info" data-toggle="tab" href="#Info-withicon"><i class="fa fa-bar-chart-o"></i> Analysis</a></li>
                    <li class="nav-item"><a class="nav-link text-info" data-toggle="tab" href="#Info-withicon"><i class="fa fa-file"></i> Report Submission</a></li>
                    <li class="nav-item"><a class="nav-link text-info" data-toggle="tab" href="#Info-withicon"><i class="fa fa-external-link"></i> Publication</a></li> -->

                    <li class="nav-item"><a class="nav-link text-info" data-toggle="tab" href="#ToDoList-withicon"><i class="fa fa-list-ol"></i> Problem <?php if($project->problem_id !== null): ?><i class="text-green fa fa-check"></i> <?php endif; ?></a></li>
                    <li class="nav-item"><a class="nav-link text-info" data-toggle="tab" href="#Backlog-withicon"><i class="fa fa-bars"></i> Idea & Solution <?php if($project->summary !== null): ?><i class="text-green fa fa-check"></i> <?php endif; ?></a></li>
                    <li class="nav-item"><a class="nav-link text-info" data-toggle="tab" href="#Sprints-withicon" ><i class="fa fa-tasks"></i> Development <?php if($project->pilotproject !== null): ?><i class="text-green fa fa-check"></i> <?php endif; ?></a></li>
                    <li class="nav-item"><a class="nav-link text-info" data-toggle="tab"href="#Analysis-withicon" ><i class="fa fa-bar-chart-o"></i> Implementation <?php if($project->sosialisasi !== null): ?><i class="text-green fa fa-check"></i> <?php endif; ?></a></li>

                </ul>
                <div class="tab-content">

<!-- INFO START -->
                    <div class="tab-pane show active" id="Info-withicon">
                    <div class="row clearfix">
                        <div class="col-lg-12 col-md-12">
                            <div class="card">
                              <form method="post" action="<?php echo e(route('project.updateinfo', $project->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="body">
                                    <div class="form-group">
                                        <h6 class="text-success">Project Name</h6>
                                        <div class="form-group">
                                            <div class="input-group">
                                            <input type="text" name="project_name" class="form-control" value="<?php echo e($project->project_name); ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <h6 class="text-success">Project Description</h6>
                                        <div class="form-group">
                                            <div class="input-group">
                                            <textarea class="form-control" name="project_description" rows="3" required><?php echo e($project->project_description); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                    <h6 class="text-success">Project Tags</h6>
                                        <div class="form-group">
                                            <div class="input-group demo-tagsinput-area">
                                            <input type="text" name="project_tags" class="form-control" data-role="tagsinput" value="<?php echo e($project->project_tags); ?>" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                    <h6 class="text-success">Unit</h6>
                                        <div class="form-group">
                                            <div class="input-group demo--area">
                                              <select name="unit_id" class="select form-control" required>

                                                <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>" <?php if ($item->id == $project->unit_id): ?>
                                                  selected
                                                <?php endif; ?>><?php echo e($item->unit_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </select>

                                            </div>
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary"> Edit Project</button>
                                </div>
                              </form>

                            </div>
                        </div>
                    </div>

                    <br>

<!-- The WInning Team -->
                    <div class="row clearfix">
                        <div class="col-lg-12">
                            <div class="header text-right">
                                <?php if($project->project_owner == Auth::user()->id): ?>
                                <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#modal1"> <i class="icon-plus"></i>  Add New Team Member</button>
                                <?php endif; ?>
                            </div>
                                <!-- Add Member Modal -->
                                <div class="modal fade launch-pricing-modal" id="modal1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6>Add New Member</h6>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                            </div>
                                            <div class="modal-body pricing_page text-justify pt-4 mb-4">
                                              <form  action="<?php echo e(url('add-project-member/'.$project->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="row clearfix">
                                                    <div class="col-12">
                                                        <div class="demo-masked-input">
                                                            <div class="row clearfix">
                                                                <div class="form-group col-lg-12 col-md-12">
                                                                    <b>Member Name</b>
                                                                    <div class="input-group mb-3">
                                                                    <select class="select form-control" name="user_id">
                                                                      <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                      <option value="<?php echo e($users->id); ?>"><?php echo e($users->name); ?></option>
                                                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-lg-12 col-md-12">
                                                                    <b>Member Role</b>
                                                                    <div class="input-group mb-3">
                                                                    <input type="text" name="role" class="form-control" placeholder="Tentukan role-nya misal: hipster, hacker, hustler" required>
                                                                    </textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-lg-12 col-md-12">
                                                                    <b>Member Status</b>
                                                                    <ul class="list-group">
                                                                        <li class="list-group-item">
                                                                            Make this member as a project owner?
                                                                            <div class="float-right">
                                                                                <label class="switch">
                                                                                    <input type="checkbox" name="status_member">
                                                                                    <span class="slider"></span>
                                                                                </label>
                                                                            </div>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                                <div class="col-lg-12 col-md-12">
                                                                <br>
                                                                <button type="submit" class="btn btn-primary"> <i class="icon-plus"></i> Add Member</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                              </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Add Member Modal -->
                                <div class="modal fade launch-impact-modal" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h6>Add Impact</h6>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                            </div>
                                            <div class="modal-body pricing_page text-justify pt-4 mb-4">
                                              <form  action="<?php echo e(url('add-project-member/'.$project->project_id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="row clearfix">
                                                    <div class="col-12">
                                                        <div class="demo-masked-input">
                                                            <div class="row clearfix">
                                                                <div class="form-group col-lg-12 col-md-12">
                                                                    <b>Impact</b>
                                                                    <div class="input-group mb-3">
                                                                    <input type="text" name="role" class="form-control" placeholder="Tentukan role-nya misal: hipster, hacker, hustler" required>
                                                                    </textarea>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-lg-12 col-md-12">
                                                                    <b>Detail</b>
                                                                    <div class="input-group mb-3">
                                                                    <input type="text" name="role" class="form-control" placeholder="Tentukan role-nya misal: hipster, hacker, hustler" required>
                                                                    </textarea>
                                                                    </div>
                                                                </div>

                                                                <div class="col-lg-12 col-md-12">
                                                                <br>
                                                                <button type="submit" class="btn btn-primary"> <i class="icon-plus"></i> Add Impact</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                              </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <h5 class="text-success"><?php echo e($project->project_name); ?> Team</h5>
                            <div class="card">
                                <div class="tab-content mt-0">
                                    <div class="tab-pane show active" id="Users">
                                        <div class="table-responsive">
                                            <table class="table table-hover table-custom spacing8">
                                                <thead>
                                                    <tr>
                                                        <th class="w60">Name</th>
                                                        <th></th>
                                                        <th></th>
                                                        <th>Role</th>
                                                        <th class="w100">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                  <?php $__currentLoopData = $project->member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="width45">
                                                        <img src="<?php echo e(asset('assets/images/xs/avatar5.jpg')); ?>" data-toggle="tooltip" data-placement="top" title="Avatar Name" alt="Avatar" class="w35 h35 rounded">
                                                        </td>
                                                        <td>
                                                            <h6 class="mb-0"><?php echo e($item->user->name); ?></h6>

                                                        </td>
                                                        <td><span class="badge badge-danger"><?php echo e($item->user_id == $project->project_owner ? 'Project Owner' : ''); ?></span></td>
                                                        <td><?php echo e($item->role); ?></td>
                                                        <td>
                                                            <button type="button" class="btn btn-sm btn-default" title="Edit"  data-toggle="modal" data-target=".launch-pricing-modal<?php echo e($item->user->id); ?>" <?php echo e($project->project_owner == Auth::user()->id ? '' : 'disabled'); ?>><i class="fa fa-edit text-primary"></i></button>
                                                            <button type="button" class="btn btn-sm btn-default "  title="Delete" data-type="confirm" data-toggle="modal" data-target=".delete-modal<?php echo e($item->user->id); ?>" <?php echo e($project->project_owner == Auth::user()->id ? '' : 'disabled'); ?>><i class="fa fa-trash-o text-danger"></i></button>
                                                        </td>
                                                    </tr>

                                                    <div class="modal fade delete-modal<?php echo e($item->user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog ">
                                                            <div class="modal-content">

                                                                <div class="modal-body pricing_page text-justify pt-4 mb-4">
                                                                  <div class="text-center">
                                                                    <i class="fa fa-warning text-warning" style="font-size:72px"></i>
                                                                    <h2>Are you sure?</h2>
                                                                    <h6>You will not be able to recover this imaginary file!</h6>
                                                                    <form class="text-center" action="<?php echo e(url('delete-project-member/'.$item->id)); ?>" id="formDelete-<?php echo e($item->id); ?>" method="post">
                                                                      <?php echo csrf_field(); ?>
                                                                      <button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
                                                                      <button type="submit" class="btn btn-danger" name="button">Delete</button>
                                                                    </form>
                                                                  </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal fade launch-pricing-modal<?php echo e($item->user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h6>Edit Member</h6>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                                                </div>
                                                                <div class="modal-body pricing_page text-justify pt-4 mb-4">
                                                                  <form class="" action="<?php echo e(url('update-project-member/'.$item->id)); ?>" method="post">
                                                                    <input type="hidden" value="<?php echo e($project->id); ?>" name="project_id">
                                                                    <?php echo csrf_field(); ?>
                                                                    <div class="row clearfix">
                                                                        <div class="col-12">
                                                                            <div class="demo-masked-input">
                                                                                <div class="row clearfix">
                                                                                    <div class="form-group col-lg-12 col-md-12">
                                                                                        <b>Member Name</b>
                                                                                        <div class="input-group mb-3">
                                                                                        <input type="text" name="member_name" class="form-control" value="<?php echo e($item->user->name); ?>" disabled required>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="form-group col-lg-12 col-md-12">
                                                                                        <b>Member Role</b>
                                                                                        <div class="input-group mb-3">
                                                                                        <input type="text" name="role" data="<?php echo e($item->role); ?>" class="form-control" value="<?php echo e($item->role); ?>" required>
                                                                                        </textarea>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="form-group col-lg-12 col-md-12">
                                                                                        <b>Project Ownership</b>
                                                                                        <ul class="list-group">
                                                                                            <li class="list-group-item">
                                                                                              <?php if($item->user_id != $project->project_owner): ?>
                                                                                                Make this member as a project owner?
                                                                                                <div class="float-right">
                                                                                                    <label class="switch">
                                                                                                      <input type="checkbox" name="owner" <?php echo e($item->role == 'Owner' ? 'checked':''); ?>>
                                                                                                      <span class="slider"></span>
                                                                                                    </label>
                                                                                                </div>
                                                                                              <?php else: ?>
                                                                                                This Member Is A Project Owner
                                                                                              <?php endif; ?>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </div>
                                                                                    <div class="col-lg-12 col-md-12">
                                                                                    <br>
                                                                                    <button type="submit" class="btn btn-primary"> <i class="icon-pencil"></i>  Edit Member</button>
                                                                                  </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                  </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                  </div>

                    <!-- Edit Member Modal -->


<!-- INFO FINISH -->

<!-- TO DO LIST START -->
                    <div class="tab-pane" id="ToDoList-withicon">
                        <div class="row clearfix">
                            <div class="col-lg-12 col-md-12">

                                <div class="card">
                                  <div class="body">
                                    <?php if($project->problem_id === null): ?>
                                    <form id="basic-form" action="<?php echo e(route('project.problem.submit',$project->id)); ?>" method="post" novalidate>
                                    <?php echo e(csrf_field()); ?>

                                        <h6 class="text-success">Problem *</h6>
                                        <div class="form-group">
                                            <label>Bagaimana</label>
                                            <input type="text" name="bagaimana" class="form-control" placeholder="Sampaikan masalah yang ditemukan" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Dari</label>
                                            <input type="text" name="dari" class="form-control" placeholder="Kondisi awal saat masalah ditemukan" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Menjadi</label>
                                            <input type="text" name="menjadi" class="form-control" placeholder="Kondisi akhir yang ingin dicapai" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Di</label>
                                            <input type="text" name="di" class="form-control" placeholder="Lokasi ditemukannya masalah" required>
                                        </div>
                                        <div class="form-group">
                                            <label>Dalam waktu</label>
                                            <input type="text" name="periode" class="form-control" placeholder="Estimasi target penyelesaian masalah" required>
                                        </div>

                                        <div class="form-group">
                                            <label>Unit</label>
                                            <select name="unit_id" class=" select form-control" required>
                                              <option value="">-Pilih Unit-</option>
                                              <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <option value="<?php echo e($item->id); ?>"><?php echo e($item->unit_name); ?></option>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <br>

                                        <div class="form-group">
                                        <h6 class="text-success">Asal ditemukanannya masalah *</h6>
                                            <div class="form-group">
                                                <select id="food" name="asal_masalah[]" class="multiselect multiselect-custom" multiple="multiple" data-parsley-required data-parsley-trigger-after-failure="change" data-parsley-errors-container="#error-multiselect">
                                                    <option value="Hasil Review">Hasil Review</option>
                                                    <option value="Suara Pelanggan">Suara Pelanggan</option>
                                                    <option value="Hasil Audit & Assessment">Hasil Audit & Assessment</option>
                                                    <option value="Dorongan Obsesi Perusahaan">Dorongan Obsesi Perusahaan</option>
                                                    <option value="Peluang Yang Diberikan Pimpinan">Peluang Yang Diberikan Pimpinan</option>
                                                    <option value="Inisiatif Individu">Inisiatif Individu</option>
                                                </select>
                                            </div>
                                            <p id="error-multiselect"></p>
                                        </div>
                                        <br>
                                        <h6 class="text-success">Problem Background *</h6>
                                        <div class="form-group">
                                            <textarea class="form-control ckeditor" id="ckeditor" name="background">
                                            </textarea>
                                        </div>
                                        <br>
                                        <button type="submit" class="btn btn-primary fa fa-paper-plane"> Submit Problem</button>
                                    </form>
                                    <?php else: ?>
                                      <label>Problem : <?php echo e($project->problem->problem); ?></label><br>
                                      <label>Problem Background</label><br>
                                      <p><?php echo $project->problem->background; ?></p>
                                    <?php endif; ?>
                                  </div>
                                    <div class="table-responsive">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
<!-- TO DO LIST FINISH -->

<!-- BACKLOG START -->
                    <div class="tab-pane" id="Backlog-withicon">
                        <div class="row clearfix">
                            <div class="col-md-12">
                              <div class="card">

                                  <div class="body">
                                    <ul class="nav nav-tabs">
                                        <li class="nav-item"><a class="nav-link show active" data-toggle="tab" href="#first">Pain & Gain <?php if($project->paingain !== null): ?> <i class="text-green fa fa-check"></i> <?php endif; ?></a> </li>

                                        <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Third">Golden Circle & Unique Value <?php if($project->goldencircle !== null): ?> <i class="text-green fa fa-check"></i> <?php endif; ?></a></li>
                                        <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Forth">Summary <?php if($project->summary !== null): ?> <i class="text-green fa fa-check"></i> <?php endif; ?></a></li>
                                    </ul>
                                      <div class="tab-content"  id="wizard_horizontal">
                                        <div class="tab-pane show vivify fadeIn active" id="first">
                                          <h2>Pain & Gain</h2>
                                          <div class="row clearfix">

                                            <form  class="col-lg-12" action="<?php echo e(route('project.myproject.paingain',$project->id)); ?>" method="post">
                                              <?php echo csrf_field(); ?>
                                              <div class="col-lg-6 text-center mb-3" style="float:left">
                                                <b class="text-red">Pain</b>
                                                <div class="input-group">

                                                  <textarea name="pain" class="form-control" rows="8" cols="80" placeholder="Tuliskan daftar hal-hal yang menyulitkan user saat ini dan menghambat mereka dalam meraih tujuannya."><?php if($project->paingain !== null): ?> <?php echo e($project->paingain->pain); ?> <?php endif; ?></textarea>
                                                </div>

                                              </div>
                                              <div class="col-lg-6 text-center mb-3" style="float:left">
                                                <b class="text-green">Gain</b>
                                                <div class="input-group">

                                                  <textarea name="gain" class="form-control" rows="8" cols="80" placeholder="Tuliskan hal-hal yang akan membuat user senang dan membuat usaha mereka lebih mudah untuk meraih tujuannya."><?php if($project->paingain !== null): ?> <?php echo e($project->paingain->gain); ?> <?php endif; ?></textarea>
                                                </div>

                                              </div>
                                              <button type="submit" class="btn btn-primary"> Save</button>
                                            </form>
                                          </div>

                                        </div>
                                        <div class="tab-pane show vivify fadeIn " id="second">
                                          <h2>User Journey Map</h2>
                                          <section>
                                            <div class="row clearfix">
                                              <form class="col-md-12" action="<?php echo e(route('project.myproject.userjourney',$project->id)); ?>" method="post" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                              <div class="col-md-12 img-thumbnail mb-3" style="min-height:200px">
                                                <?php if($project->userjourney !== null): ?>
                                                  <img src="<?php echo e(asset('file/'.$project->userjourney->file)); ?>" class="img-responsive" width="100%" alt="">
                                                <?php endif; ?>
                                              </div>
                                              <div class="col-sm-6 text-center" style="float:left">
                                                <a href="#" class="btn btn-outline-success">Download Template</a>
                                              </div>
                                              <div class="col-sm-6 text-center" style="float:left">
                                                  <input type="file" name="file_upload" value="">
                                              </div>
                                              <button type="submit" class="btn btn-primary"> Save</button>
                                              </form>
                                            </div>


                                          </section>
                                        </div>
                                        <div class="tab-pane show vivify fadeIn " id="Third">
                                          <h2>Golden Circle & Unique Value</h2>
                                          <form class="" action="<?php echo e(route('project.myproject.goldencircle',$project->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>

                                          <div class="row clearfix">
                                            <div class="col-lg-5 col-md-6 ">
                                              <img src="<?php echo e(asset('image/gc.png')); ?>" alt="">
                                            </div>
                                            <div class="col-lg-6 col-md-6 ">
                                              <b>Why</b>
                                              <div class="input-group">
                                                <textarea name="why" class="form-control" rows="4 " cols="80"><?php if($project->goldencircle !== null): ?> <?php echo e($project->goldencircle->why); ?> <?php endif; ?></textarea>
                                              </div>
                                              <b>How</b>
                                              <div class="input-group">
                                                <textarea name="how" class="form-control" rows="4 " cols="80"><?php if($project->goldencircle !== null): ?> <?php echo e($project->goldencircle->how); ?> <?php endif; ?></textarea>
                                              </div>
                                              <b>What</b>
                                              <div class="input-group">
                                                <textarea name="what" class="form-control" rows="4 " cols="80"><?php if($project->goldencircle !== null): ?> <?php echo e($project->goldencircle->what); ?> <?php endif; ?></textarea>
                                              </div>
                                            </div>
                                            <div class="col-md-12">
                                              <b>Unique Value</b>
                                              <div class="input-group">
                                                <textarea name="unique_value" class="form-control" rows="4 " cols="80"><?php if($project->goldencircle !== null): ?> <?php echo e($project->goldencircle->unique_value); ?> <?php endif; ?></textarea>
                                              </div>
                                              <button type="submit" name="button" class="btn btn-primary">Save</button>
                                            </div>

                                          </div>

                                          </form>
                                        </div>
                                        <div class="tab-pane show vivify fadeIn " id="Forth">
                                          <h2>Summary</h2>
                                          <form class="" action="<?php echo e(route('project.myproject.summary',$project->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                          <div class="row clearfix">
                                            <div class="col-md-12 ">
                                              <div class="input-group mb-3">
                                                <textarea name="summary" class="form-control" rows="8" cols="120" placeholder="Ceritakan project yang akan anda kerjakan"><?php if($project->summary !== null): ?> <?php echo e($project->summary->summary); ?> <?php endif; ?></textarea>

                                              </div>
                                              <button type="submit" name="button" class="btn btn-primary">Save</button>
                                            </div>
                                          </div>

                                        </form>
                                        </div>

                                      </div>
                                  </div>
                              </div>
                            </div>
                            <div class="col-md-12">

                            </div>
                        </div>
                    </div>

<!-- BACKLOG FINISH -->

<!-- SPRINT START -->
                    <div class="tab-pane" id="Sprints-withicon">
                        <div class="row clearfix">
                          <div class="col-md-12">
                            <div class="card">

                                <div class="body">
                                  <ul class="nav nav-tabs">
                                      <li class="nav-item"><a class="nav-link show active" data-toggle="tab" href="#firstd">Product Development <?php if($project->productdevelopment !== null): ?> <i class="text-green fa fa-check"></i> <?php endif; ?></a></li>
                                      <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#secondd">Pilot Project <?php if($project->pilotproject !== null): ?> <i class="text-green fa fa-check"></i> <?php endif; ?></a></li>
                                  </ul>
                                    <div class="tab-content"  id="wizard_horizontal">
                                      <div class="tab-pane show vivify fadeIn active" id="firstd">\
                                        <div class="row clearfix">

                                          <form  class="col-lg-12" action="<?php echo e(route('project.myproject.productdevelopment',$project->id)); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="col-lg-12  mb-3" style="float:left">
                                              <b class="">Development Story</b>
                                              <div class="input-group">
                                              <textarea name="development_story" class="form-control" rows="8" cols="80"><?php if($project->productdevelopment !== null): ?><?php echo e($project->productdevelopment->development_story); ?> <?php endif; ?></textarea>
                                              </div>
                                            </div>
                                            <div class="col-lg-12  mb-3" style="float:left">
                                              <b>Upload Mockup/Prototype/Poster</b><br>
                                              <?php if($project->productdevelopment !== null): ?>
                                                <a href="<?php echo e(asset('file/mockup/'.$project->productdevelopment->mockup_file)); ?>" target="_blank">File Mockup</a><br>
                                                <input type="file" name="mockup_file[]" value="" multiple>
                                              <?php else: ?>
                                              <div class="input-group">
                                                <input type="file" name="mockup_file[]" value="" multiple>
                                              </div>
                                              <?php endif; ?>
                                            </div>
                                            <div class="col-lg-12  mb-3" style="float:left">
                                              <b>Upload Dokumentasi</b><br>
                                              <?php if($project->productdevelopment !== null): ?>
                                                <a href="<?php echo e(asset('file/doc/'.$project->productdevelopment->doc_file)); ?>" target="_blank">File Dokumentasi</a><br>
                                                <input type="file" name="doc_file[]" value="" multiple>
                                              <?php else: ?>
                                              <div class="input-group">
                                                <input type="file" name="doc_file[]" value="" multiple>
                                              </div>
                                              <?php endif; ?>
                                            </div>
                                            <button type="submit" class="btn btn-primary"> Save</button>
                                          </form>
                                        </div>

                                      </div>
                                      <div class="tab-pane show vivify fadeIn " id="secondd">
                                        <!-- <h2>User Journey Map</h2> -->
                                        <section>
                                          <div class="row clearfix">
                                            <form class="col-md-12" action="<?php echo e(route('project.myproject.pilotproject',$project->id)); ?>" method="post" enctype="multipart/form-data">
                                              <?php echo csrf_field(); ?>
                                              <div class="col-lg-6">
                                                <b>Lokasi Pilot</b>
                                                <div class="input-group">
                                                  <input type="text" class="form-control" name="lokasi_pilot" value="<?php if($project->pilotproject !== null): ?> <?php echo e($project->pilotproject->lokasi_pilot); ?> <?php endif; ?>">
                                                </div>
                                              </div>
                                              <div class="col-lg-6">
                                                <b>Periode</b><br>
                                                <label><?php if($project->pilotproject !== null ): ?><?php echo e($project->pilotproject->periode); ?> <?php endif; ?></label>
                                                <div class="input-daterange input-group" data-provide="datepicker">
                                                    <input type="text" class="input-sm form-control" name="range_start">
                                                    <span class="input-group-addon range-to">to</span>
                                                    <input type="text" class="input-sm form-control" name="range_end">
                                                </div>
                                              </div>
                                              <div class="col-lg-12  mb-3" style="float:left">
                                                <b class="">Development Story</b>
                                                <div class="input-group">
                                                  <textarea name="development_story" class="form-control" rows="8" cols="80"><?php if($project->pilotproject !== null): ?> <?php echo e($project->pilotproject->development_story); ?> <?php endif; ?></textarea>
                                                </div>

                                              </div>
                                            <div class="col-md-12 mb-3 " style="float:left">
                                              <b>Upload Dokumentasi Pilot Project</b><br>
                                              <?php if($project->pilotproject !== null): ?>

                                                <a href="<?php echo e(asset('file/doc/'.$project->pilotproject)); ?>">Dokumentasi</a>
                                                <input type="file" name="doc_file[]" value="" multiple>
                                              <?php else: ?>
                                                <input type="file" name="doc_file[]" value="" multiple>
                                              <?php endif; ?>
                                            </div>
                                            <!-- <div class="col-lg-12"> -->
                                              <button type="submit" class="btn btn-primary"> Save</button>
                                            <!-- </div> -->
                                            </form>
                                          </div>


                                        </section>
                                      </div>


                                    </div>
                                </div>
                            </div>
                          </div>
                        </div>
                    </div>
<!-- SPRINT FINISH -->

<!-- ANALYSIS START -->
                    <div class="tab-pane" id="Analysis-withicon">
                        <div class="row row-cards">
                            <div class="col-md-12">
                              <div class="card">

                                  <div class="body">
                                    <ul class="nav nav-tabs">
                                        <li class="nav-item"><a class="nav-link show active" data-toggle="tab" href="#firsti">Dasar Implementasi</a></li>
                                        <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#secondi">Sosialisasi & Dokumentasi</a></li>
                                        <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#Thirdi">Impact</a></li>
                                    </ul>
                                      <div class="tab-content"  id="wizard_horizontal">
                                        <div class="tab-pane show vivify fadeIn active" id="firsti">

                                          <div class="row clearfix">

                                            <form  class="col-lg-12" action="<?php echo e(route('project.myproject.dasarimplementasi',$project->id)); ?>" method="post" enctype="multipart/form-data">
                                              <?php echo csrf_field(); ?>
                                              <b>Dasar Implementasi</b>
                                              <div class="input-group mb-3 ">
                                                <input type="text" class="form-control" name="dasar_implementasi" value="">
                                              </div>
                                              <b>Upload Avidance</b>
                                              <div class="input-group mb-3">

                                                  <input type="file" name="avidance_file" value="">


                                              </div>
                                              <button type="submit" class="btn btn-primary"> Save</button>
                                            </form>
                                            <table class="table">
                                              <thead>
                                                <tr>
                                                  <th>Dasar Implementasi</th>
                                                  <th>Avidance File</th>
                                                  <th>Action</th>
                                                </tr>
                                              </thead>
                                              <tbody>
                                                <?php $__currentLoopData = $project->dasarimplementasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dasar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                  <td><?php echo e($dasar->dasar_implementasi); ?></td>
                                                  <td> <a href="<?php echo e(asset('file/doc/'.$dasar->avidance)); ?>" target="_blank">File</a> </td>
                                                  <td><button type="button" class="btn btn-sm btn-default " title="Delete" data-type="confirm" data-toggle="modal" data-target=".ondelete-modal<?php echo e($dasar->id); ?>"><i class="fa fa-trash-o text-danger"></i></button></td>
                                                </tr>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                              </tbody>
                                            </table>
                                          </div>

                                        </div>
                                        <div class="tab-pane show vivify fadeIn " id="secondi">

                                          <section>
                                            <div class="row clearfix">
                                              <form class="col-md-12" action="<?php echo e(route('project.myproject.sosialisasi',$project->id)); ?>" method="post" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <b>Judul</b>
                                                <div class="input-group mb-3">
                                                  <input type="text" class="form-control" name="judul" value="">
                                                </div>
                                                <b>Location</b>
                                                <div class="input-group mb-3">
                                                  <input type="text" class="form-control" name="lokasi" value="">
                                                </div>
                                                <b>Posts</b>
                                                <div class="input-group mb-3">
                                                  <textarea name="post" class="form-control" rows="8" cols="80"></textarea>
                                                </div>
                                                <b>Upload Image</b>
                                                <div class="input-group mb-3">
                                                  <input type="file"  name="image[]" multiple value="">
                                                </div>
                                                <button type="submit" class="btn btn-primary"> Save</button>
                                              </form>
                                            </div>


                                          </section>
                                        </div>
                                        <div class="tab-pane show vivify fadeIn " id="Thirdi">
                                          <table class="table table-bordered">
                                            <thead>
                                              <tr>
                                                <th>Impact</th>
                                                <th>Detail</th>
                                                <th>Action</th>
                                              </tr>
                                            </thead>
                                            <tbody>
                                              <?php $__currentLoopData = $project->impact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $impact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                              <tr>
                                                <td><?php echo e($impact->impact); ?></td>
                                                <td><?php echo e($impact->detail); ?></td>
                                                <td><button type="button" class="btn btn-sm btn-default " title="Delete" data-type="confirm" data-toggle="modal" data-target=".onondelete-modal<?php echo e($impact->id); ?>"><i class="fa fa-trash-o text-danger"></i></button></td>
                                              </tr>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                          </table>
                                          <button type="button" data-toggle="modal" data-target=".new-project-modal" class="btn btn-primary" name="button">Add Impact</button>


                                        </div>
                                        <div class="tab-pane show vivify fadeIn " id="Forth">
                                          <h2>Summary</h2>
                                          <form class="" action="index.html" method="post">

                                          <div class="row clearfix">
                                            <div class="col-md-12 ">
                                              <div class="input-group mb-3">
                                                <textarea name="name" class="form-control" rows="8" cols="120" placeholder="Ceritakan project yang akan anda kerjakan"></textarea>

                                              </div>
                                              <button type="submit" name="button" class="btn btn-primary">Save</button>
                                            </div>
                                          </div>

                                        </form>
                                        </div>

                                      </div>
                                  </div>
                              </div>
                            </div>
                        </div>
                    </div>
<!-- ANALYSIS FINISH -->

<!-- REPORT SUBMISSION START -->
                    <div class="tab-pane" id="ReportSubmission-withicon">
                        <div class="header text-right">
                            <button type="submit" class="btn btn-primary" data-toggle="modal" data-target=".launch-pricing-modal-report"> <i class="icon-plus"></i>  Add Project Report</button>
                        </div>
                        <div class="modal fade launch-pricing-modal-report" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-lg">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h6>Add Report</h6>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                    </div>
                                    <div class="modal-body pricing_page text-justify pt-4 mb-4">
                                        <div class="row clearfix">
                                            <div class="col-12">
                                                <div class="demo-masked-input">
                                                    <div class="row clearfix">
                                                        <div class="form-group col-lg-12 col-md-12">
                                                            <b>Report Title</b>
                                                            <div class="input-group mb-3">
                                                            <input type="text" name="report_title" class="form-control" placeholder="Tuliskan title reportnya" required>
                                                            </div>
                                                        </div>
                                                        <div class="form-group col-lg-12 col-md-12">
                                                        <b>Upload Your File</b>
                                                            <div class="header">
                                                                <p>Limit file size 2 MB</h2>
                                                            </div>
                                                            <div class="body">
                                                                <input type="file" class="dropify" data-max-file-size="2000K">
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-12 col-md-12">
                                                        <br>
                                                        <button type="submit" class="btn btn-primary"> <i class="icon-paper-plane"></i> Submit Report</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="tab-content mt-0">
                                <div class="tab-pane show active" id="Users">
                                    <div class="table-responsive">
                                        <table class="table table-hover table-custom spacing8">
                                            <thead>
                                                <tr>
                                                    <th>Title</th>
                                                    <th>File</th>
                                                    <th>Upload Date</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Proposal CV Catalist</td>
                                                    <td><a href="#" target="_blank"><i class="fa fa-file text-primary"></i>  Area2_Proposal CV_Catalist </a></td>
                                                    <td>11 September 2019 19:51</td>
                                                    <td>
                                                        <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Download File"><i class="fa fa-download text-primary"></i></button>
                                                        <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o text-danger"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Laporan CV Catalist</td>
                                                    <td><a href="#" target="_blank"><i class="fa fa-file text-primary"></i>  Area2_Laporan CV_Catalist </a></td>
                                                    <td>14 September 2019 12:31</td>
                                                    <td>
                                                        <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Download File"><i class="fa fa-download text-primary"></i></button>
                                                        <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o text-danger"></i></button>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Proposal PV Catalist</td>
                                                    <td><a href="#" target="_blank"><i class="fa fa-file text-primary"></i>  Area2_Proposal PV_Catalist </a></td>
                                                    <td>17 September 2019 15:11</td>
                                                    <td>
                                                        <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Download File"><i class="fa fa-download text-primary"></i></button>
                                                        <button type="button" class="btn btn-sm btn-default js-sweetalert" title="Delete" data-type="confirm"><i class="fa fa-trash-o text-danger"></i></button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
<!-- REPORT SUBMISSION FINISH -->

<!-- PUBLICATION START -->
                    <div class="tab-pane" id="Publication-withicon">
                        <h6>Publication</h6>
                        <p>Food truck fixie locavore, accusamus mcsweeney's marfa nulla single-origin coffee squid. Exercitation +1 labore velit, blog sartorial PBR leggings next level wes anderson artisan four loko farm-to-table craft beer twee. Qui photo booth letterpress, commodo enim craft beer mlkshk aliquip jean shorts ullamco ad vinyl cillum PBR. Homo nostrud organic, assumenda labore aesthetic magna delectus mollit. Keytar helvetica</p>
                    </div>
<!-- PUBLICATION FINISH -->
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade new-project-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Setup New Project</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
              <form  action="<?php echo e(route('project.myproject.impact',$project->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="row clearfix">
                    <div class="col-12">
                        <div class="demo-masked-input">
                            <div class="row clearfix">
                                <div class="form-group col-lg-12 col-md-12">
                                    <b>Impact</b>
                                    <div class="input-group mb-3">
                                    <input type="text" name="impact" class="form-control" placeholder="" required>
                                    </textarea>
                                    </div>
                                </div>
                                <div class="form-group col-lg-12 col-md-12">
                                    <b>Detail</b>
                                    <div class="input-group mb-3">
                                    <input type="text" name="detail" class="form-control" placeholder="" required>
                                    </textarea>
                                    </div>
                                </div>

                                <div class="col-lg-12 col-md-12">
                                <br>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-round btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-round btn-primary">Save </button>
            </div>
            </form>
        </div>
    </div>
</div>

<?php $__currentLoopData = $project->dasarimplementasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dasar1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal fade ondelete-modal<?php echo e($dasar1->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content">

            <div class="modal-body pricing_page text-justify pt-4 mb-4">
              <div class="text-center">
                <i class="fa fa-warning text-warning" style="font-size:72px"></i>
                <h2>Are you sure?</h2>
                <h6>You will not be able to recover this imaginary file!</h6>
                <form class="text-center" action="<?php echo e(url('delete-dasar/'.$dasar1->id)); ?>" id="formDelete-<?php echo e($dasar1->id); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
                  <button type="submit" class="btn btn-danger" name="button">Delete</button>
                </form>
              </div>

            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $project->impact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $impact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="modal fade onondelete-modal<?php echo e($impact->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog ">
        <div class="modal-content">

            <div class="modal-body pricing_page text-justify pt-4 mb-4">
              <div class="text-center">
                <i class="fa fa-warning text-warning" style="font-size:72px"></i>
                <h2>Are you sure?</h2>
                <h6>You will not be able to recover this imaginary file!</h6>
                <form class="text-center" action="<?php echo e(url('delete-impact/'.$impact->id)); ?>" id="formDelete-<?php echo e($impact->id); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <button type="button" class="btn btn-primary" data-dismiss="modal" aria-label="Close">Cancel</button>
                  <button type="submit" class="btn btn-danger" name="button">Delete</button>
                </form>
              </div>

            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/summernote/dist/summernote.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/sweetalert/sweetalert.css')); ?>"/>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.css')); ?>">
<style>
    td.details-control {
    background: url('../assets/images/details_open.png') no-repeat center center;
    cursor: pointer;
}
    tr.shown td.details-control {
        background: url('../assets/images/details_close.png') no-repeat center center;
    }
</style>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap-datepicker/css/bootstrap-datepicker3.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/nestable/jquery-nestable.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/c3/c3.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/summernote/dist/summernote.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatablescripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/sweetalert/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.js')); ?>"></script><!-- Bootstrap Tags Input Plugin Js -->
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/tables/jquery-datatable.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/js/select2.min.js"></script>
<script src="<?php echo e(asset('assets/vendor/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/forms/editors.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.js')); ?>"></script><!-- Bootstrap Tags Input Plugin Js -->
<script src="<?php echo e(asset('assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/parsleyjs/js/parsley.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/summernote/dist/summernote.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/selects/select2-bootstrap.css')); ?>">
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/js/select2.min.js"></script>
<script>
$(function() {
    // validation needs name of the element
    $('#food').multiselect();

    // initialize after multiselect
    $('#basic-form').parsley();
});
</script>
<script type="text/javascript">

$(document).ready(function() {
  $(".select").select2({
    theme: "bootstrap",
    width:'100%',
     placeholder: "Pilih Member"
   });
});
</script>
<script type="text/javascript">

$(document).ready(function() {
  $(".select").select2({
    theme: "bootstrap",
    width:'100%',
     placeholder: "Pilih Member"
   });
   //
   // $('#check-add').click(function(){
   //    let roleData = $('#role-add').attr('data');
   //    let role = $('#role-add').val();
   //    if(role != 'Owner'){
   //      $('#role-add').val('Owner');
   //      $('#role-add').attr('readonly', 'readonly');
   //    }else {
   //      $('#role-add').val(roleData);
   //      $('#role-add').attr('readonly', null);
   //    }
   //  })
});
</script>
<script type="text/javascript">
function confirmDelete(id) {
    swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover this imaginary file!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
        })
        .then((willDelete) => {
        if (willDelete) {
            swal("Poof! Your imaginary file has been deleted!", {
            icon: "success",
            })
            .then(() => {
                $('#formDelete-' + id).submit();
            });
        } else {
            swal("Your imaginary file is safe!");
        }
        });
}
</script>
<script>
$('#multiselect3-all').multiselect({
    includeSelectAllOption: true,
});
</script>
<script src="<?php echo e(asset('assets/vendor/nestable/jquery.nestable.js')); ?>"></script>

<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/ui/sortable-nestable.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/c3.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/charts/c3.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/motekar/resources/views/project/projectdetail.blade.php ENDPATH**/ ?>