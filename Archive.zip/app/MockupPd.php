<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MockupPd extends Model
{
    protected $table = 'mockup_pd';
}
