<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DokumentasiPilot extends Model
{
    protected $table = 'dokumentasi_pilot';
}
