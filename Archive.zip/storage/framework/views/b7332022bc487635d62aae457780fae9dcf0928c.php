<?php $__env->startSection('content'); ?>


<!-- carousel slider -->
<div class="container-fluid">
    <div class="block-header">
        <div class="row clearfix">
            <div class="col-md-6 col-sm-12">
                <h1>Home</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href=""><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item active">Home</li>
                        <!-- <li class="breadcrumb-item"></li> -->
                        <!-- <li class="breadcrumb-item active"></li> -->
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div id="app">
      <div class="row clearfix">
        <div class="col-lg-8 col-md-12">
          <div class="x_content bs-example-popovers">
            <div class="slider-item alert-success" >
              <div class="row slider-text align-items-center justify-content-center">
                <div class="col-md-12 ftco-animate text-center">
                  <img src="<?php echo e(asset('image/Bogor.png')); ?>" alt="" style="    width: 100%;">
                </div>
              </div>
            </div>
          </div>
          <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($item->sosialisasi): ?>
            <div class="card mt-3">

                  <div class="body">
                    <h5 class="card-title"><?php echo e($item->sosialisasi->judul); ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($item->sosialisasi->created_at); ?></h6>
                    <div class="mb-3">
                      <p><?php echo e($item->sosialisasi->post); ?></p>
                      <?php $__currentLoopData = $item->sosialisasi->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <img src="<?php echo e(asset('file/doc/'.$image->image)); ?>" style="width:100px" alt="">
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="card-footer" style="background:#fff; border-color:#e1e8ed" >
                      <div class="row clearfix">
                        <div class="col-md-6">
                          <i class="fa fa-love"></i>
                          <span onclick="like('<?php echo e($item->sosialisasi->id); ?>',$(this))" cliktwice="true" style="cursor:pointer" disabled>
                            <i id="like-<?php echo e($item->sosialisasi->id); ?>" class="fa  fa-heart <?php echo e(in_array(Auth::user()->id, $item->sosialisasi->like->pluck('user_id')->toArray()) ? 'like' : 'dislike'); ?>"></i>
                            Like (<span id="like-count-<?php echo e($item->sosialisasi->id); ?>"><?php echo e(count($item->sosialisasi->like)); ?></span>)
                          </span>
                        </div>
                        <div class="col-md-6">
                          <i class="fa fa-comments-o"> Comment</i> (<?php echo e(count($item->sosialisasi->comment)); ?>)
                        </div>
                      </div>
                      <br>
                      <ul class="timeline"  style="background:#fff;border-top:1px solid; border-color:#e1e8ed;padding-top:20px !important">
                        <?php if(count($item->sosialisasi->comment) != 0): ?>
                          <?php $__currentLoopData = $item->sosialisasi->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <li class="timeline-item">
                              <div class="timeline-marker"></div>
                              <div class="timeline-content">
                                <ul class="list-unstyled team-info sm margin-0">
                                    <li><img src="../assets/images/xs/avatar3.jpg" alt="Avatar"></li>
                                    <li>
                                      <p style="margin-left:15px"><?php echo e($cmm->user->name); ?></p>
                                    </li>
                                </ul>
                                  <p class="text-muted mt-0 mb-2"><?php echo e($cmm->created_at); ?></p>
                                  <p><?php echo e($cmm->comment); ?></p>
                              </div>
                          </li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                          <li class="">
                            <br>
                              <div class="timeline-content">
                                <h6>Jadilah Yang Pertaman Menuliskan Komentar Anda</h6>
                              </div>
                          </li>
                        <?php endif; ?>
                      </ul>

                      <!-- comment -->
                      <br>
                      <h5 class="card-title">Submit Your Comment</h5>
                      <form action="<?php echo e(route('comment.store', $item->sosialisasi->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="row clearfix">
                          <div class="col-12">
                              <textarea class="form-control" name="comment" style="min-height:100px"></textarea>
                          </div>
                          <div class="col-sm-12">
                              <div class="mt-4">
                                  <button type="submit" class="btn btn-primary">Submit</button>
                              </div>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
          <?php endif; ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-lg-4 col-md-12">
          <div class="card">
            <div class="body">
              <img src="<?php echo e(asset('image/kipas-sakti.png')); ?>" class="card-img-top" alt="">
            </div>
          </div>
          <div class="card">
            <div class="body">
              <div class="d-flex align-items-center">
                    <div class="ml-4">
                        <span>Problem</span>
                        <h4 class="mb-0 font-weight-medium"><?php echo e(count($problem)); ?></h4>
                    </div>
                </div>
            </div>
          </div>
          <div class="card">
            <div class="body">
              <div class="d-flex align-items-center">
                    <div class="ml-4">
                        <span>Project</span>
                        <h4 class="mb-0 font-weight-medium"><?php echo e(count($project)); ?></h4>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/c3/c3.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/light-gallery/css/lightgallery.css')); ?>">
<style>
  .like{
    color:red;
  }

  .dislike{
    color:#d1d1d1;
  }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/c3.bundle.js')); ?>"></script>

<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/index.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/lightgallery.bundle.js')); ?>"></script>

<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/medias/image-gallery.js')); ?>"></script>
<script type="text/javascript">
  function like(id,datatwice) {
    var twice = datatwice.attr("cliktwice");
    datatwice.attr("cliktwice","false");
    if(twice == 'true'){
      var count = parseInt($("#like-count-"+id).text());
      $.ajax({
         type:'POST',
         url:'<?php echo e(url("like/")); ?>/'+id,
         data:{"_token": "<?php echo e(csrf_token()); ?>"},
         success:function(data) {
           datatwice.attr("cliktwice","true");
           if(data == "like"){
             $("#like-"+id).removeClass("dislike").addClass("like");
             $("#like-count-"+id).text(count+1);
           }else {
             $("#like-"+id).removeClass("like").addClass("dislike");
             $("#like-count-"+id).text(count-1);
           }
         }
      });
    }
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/motekar/resources/views/home.blade.php ENDPATH**/ ?>