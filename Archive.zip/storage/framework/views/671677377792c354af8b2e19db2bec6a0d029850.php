<?php $__env->startSection('parentPageTitle', 'Problem'); ?>
<?php $__env->startSection('title', 'Problem Detail'); ?>


<?php $__env->startSection('content'); ?>
<!-- carousel slider -->
<div class="container-fluid">
    <div class="block-header">
        <div class="row clearfix">
            <div class="col-md-6 col-sm-12">
                <h1>Problem Pool</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href=""><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item active">Project Pool</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div id="app">
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
            <strong><?php echo e($message); ?></strong>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($message); ?></strong>
        </div>
    <?php endif; ?>

    <?php if($message = Session::get('warning')): ?>
        <div class="alert alert-warning alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($message); ?></strong>
    </div>
    <?php endif; ?>

    <?php if($message = Session::get('info')): ?>
        <div class="alert alert-info alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong><?php echo e($message); ?></strong>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
        <button type="button" class="close" data-dismiss="alert">×</button>
        Please check the form below for errors
    </div>
    <?php endif; ?>
    <div class="row clearfix">
        <div class="col-lg-12 col-md-12">
        <div class="header text-right">
        <a href="/problem/myproblemlist" class="btn btn-success fa fa-arrow-left" title="Back"> </a>
        <?php if($data_problem_detail->user_id == Auth::user()->id): ?>
        <a href="<?php echo e(route('editproblem',$data_problem_detail->problem_id)); ?>" class="btn btn-primary fa fa-edit" title="Edit"></a>
        <?php endif; ?>
        </div>
        <div class="card">
            <div class="body">
                <div class="content">
                    <h6>Problem</h6>
                    <span><?php echo e($data_problem_detail->problem); ?></span>
                </div>
            </div>
            <div class="body">
                <div class="content">
                    <h6>Problem Background</h6>
                    <?php echo $data_problem_detail->background; ?>

                </div>
            </div>
            <div class="card-footer">
                <a href="#"><i class="fa fa-fire"></i> Asal Masalah:
                <?php $__currentLoopData = explode(',', $data_problem_detail->asal_masalah); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge badge-info text-uppercase">
                    <?php echo e($asal); ?>

                    </span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </a>
                <br>
                <br>
                <a href="#"><i class="fa fa-check-circle"></i> Status:
                   <?php if($data_problem_detail->status == '0'): ?>
                   <span class="badge badge-info text-uppercase">
                   Solved
                   </span>
                    <?php endif; ?>
                    <?php if($data_problem_detail->status == '2'): ?>
                    <span class="badge badge-info text-uppercase">
                    On Development
                    </span>
                     <?php endif; ?>
                     <?php if($data_problem_detail->status == '1'): ?>
                     <span class="badge badge-info text-uppercase">
                     Need Team Project
                     </span>
                      <?php endif; ?>
                <?php $__currentLoopData = explode(',', $data_problem_detail->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </a>
            </div>
        </div>
        </div>
    </div>

    <div class="row clearfix">
        <!-- Karyawan yang tertarik dengan masalahmu -->
        <div class="col-lg-12 col-md-12">
        <div class="card">
                <div class="header">
                    <h2><strong>Other Employee Who Interest to Your Problem</strong></h2>
                </div>
                <div class="body">
                  <?php $__currentLoopData = $data_problem_detail->interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dpd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <ul class="right_chat w_followers list-unstyled mb-0">
                        <li class="online">
                            <a href="javascript:void(0);">
                                <div class="media">
                                    <img class="media-object " src="../../assets/images/xs/avatar5.jpg" alt="">
                                    <div class="media-body">
                                        <span class="name"><?php echo e($dpd->user->name); ?></span>
                                        <span class="message"><?php echo e($dpd->created_at); ?></span>
                                    </div>
                                </div>
                            </a>
                        </li>
                    </ul>
                    <hr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>


    <!-- launch-detil -->
    <div class="modal fade launch-pricing-modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
      <form method="post" id="form-method-problem-Project">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="problem_id" value="<?php echo e($data_problem_detail->problem_id); ?>">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <li class="online">
                        <a href="javascript:void(0);">
                            <div class="media">
                                <img class="media-object " src="../../assets/images/xs/avatar5.jpg" alt="">
                                <div class="media-body">
                                    <span class="name" id="modal-user-name"></span>
                                    <!-- <span class="message" id="modal-user-message">Officer 3 Sales & Customer Care CBI, BJD</span> -->
                                </div>
                            </div>
                        </a>
                    </li>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body pricing_page text-justify pt-4 mb-4">
                    <div class="row clearfix">
                        <div class="col-12">
                            <h6 class="text-primary">Motivasi bergabung</h6>
                            <p class="mb-4" id="modal-motivate"></p>
                            <h6 class="text-primary">Ide awal untuk penyelesaian masalah</h6>
                            <p class="mb-4" id="modal-idea"></p>
                            <h6 class="text-primary">Expected role</h6>
                            <p class="mb-4" id="modal-role"></p>
                        </div>
                        <div class="col-12">
                            <h6 class="text-success">Apakah <span id="modal-user-success-name"></span> orang yang kamu cari? Bentuk tim mu sekarang!</h6>
                            <div class="demo-masked-input">
                                <div class="row clearfix">
                                    <div class="col-lg-6 col-md-6">
                                        <div class="input-group mb-3">
                                        <input type="text" class="form-control" id="modal-input-name" disabled>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                        <div class="input-group mb-3">
                                        <input type="text" name="role" class="form-control" placeholder="Tentukan role-nya misal: hipster, hacker, hustler" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                        <b>Project Name</b>
                                        <div class="input-group mb-3">
                                          <?php if($data_problem_detail->project): ?>
                                          <input type="hidden" name="project_id" value="<?php echo e($data_problem_detail->project->project_id); ?>">
                                          <input type="text" class="form-control" value="<?php echo e($data_problem_detail->project->project_name); ?>" readonly>
                                          <?php else: ?>
                                          <input type="text" name="project_name" class="form-control" placeholder="Team name" required>
                                          <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6">
                                    <br>
                                    <button class="btn btn-primary" >Create Your Winning Team!</button>
                                    <button class="btn btn-danger" type="button" class="close" data-dismiss="modal" aria-label="Close">Cancel</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </form>
    </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/summernote/dist/summernote.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/sweetalert/sweetalert.css')); ?>"/>
<style>
    td.details-control {
    background: url('../assets/images/details_open.png') no-repeat center center;
    cursor: pointer;
}
    tr.shown td.details-control {
        background: url('../assets/images/details_close.png') no-repeat center center;
    }
</style>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/summernote/dist/summernote.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/datatablescripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/sweetalert/sweetalert.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/tables/jquery-datatable.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js')); ?>"></script>
<script>
$('#multiselect3-all').multiselect({
    includeSelectAllOption: true,
});
</script>
<script>
$('#multiselect3-all').multiselect({
    includeSelectAllOption: true,
});

function openmodal(data){
  console.log(data);
  $('#modal-user-name').text(data.user.name);
  $('#modal-motivate').text(data.motivate);
  $('#modal-idea').text(data.idea);
  $('#modal-role').html(data.expected_role);
  $('#modal-input-name').val(data.user.name);
  $('#form-method-problem-Project').attr("action", "<?php echo e(url('problem/interests/to/project/')); ?>/"+data.user_id);
}

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/motekar/resources/views/problem/problemdetail.blade.php ENDPATH**/ ?>