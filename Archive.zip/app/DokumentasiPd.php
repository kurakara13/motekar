<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DokumentasiPd extends Model
{
    protected $table = 'dokumentasi_pd';

}
