<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserJourney extends Model
{
    protected $table = 'userjourneys';
}
