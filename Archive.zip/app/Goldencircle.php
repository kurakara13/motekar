<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Goldencircle extends Model
{
    //
}
