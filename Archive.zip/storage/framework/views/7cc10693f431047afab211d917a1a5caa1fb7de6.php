<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/selects/selectize.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/selects/selectize.default.css')); ?>">
<!-- carousel slider -->
<div class="container-fluid">
    <div class="block-header">
        <div class="row clearfix">
            <div class="col-md-6 col-sm-12">
                <h1>Problem Pool</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href=""><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item active">My Project </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div id="app">
      <div class="row clearfix">
          <div class="col-lg-12">
          </div>
              <div class="card">
                <div class="body">
                  <div class="card-title">
                    <h5><?php echo e($projects->project_name); ?></h5>
                  </div>
                  <div class="row clearfix">
                    <div class="col-md-8">
                      <h5 class="text-success">Development Summary</h5>
                      <p><?php echo e($projects->productdevelopment->development_story); ?></p>
                    </div>
                    <div class="col-md-4">
                      <h5 class="text-success">Document</h5>
                      <a href="<?php echo e(asset('file/mockup/'.$projects->productdevelopment->mockup_file)); ?>"> <i class="fa fa-file-pdf-o"></i> Mockup File</a><br>
                      <a href="<?php echo e(asset('file/mockup/'.$projects->productdevelopment->doc_file)); ?>"> <i class="fa fa-file-pdf-o"></i> Dokumentasi File</a><br>
                      <a href="<?php echo e(asset('file/mockup/'.$projects->pilotproject->doc_file)); ?>"> <i class="fa fa-file-pdf-o"></i> Dokumentasi Pilot Project File</a>
                    </div>
                  </div>
                </div>

              </div>
            </div>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/dataTables.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/fixedeader/dataTables.fixedcolumns.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/jquery-datatable/fixedeader/dataTables.fixedheader.bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/sweetalert/sweetalert.css')); ?>"/>
<style>
    td.details-control {
    background: url('../assets/images/details_open.png') no-repeat center center;
    cursor: pointer;
}
    tr.shown td.details-control {
        background: url('../assets/images/details_close.png') no-repeat center center;
    }
</style>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap-multiselect/bootstrap-multiselect.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/datatablescripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.colVis.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/jquery-datatable/buttons/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/sweetalert/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap-tagsinput/bootstrap-tagsinput.js')); ?>"></script><!-- Bootstrap Tags Input Plugin Js -->
<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/tables/jquery-datatable.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/selects/selectize.min.js')); ?>">
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/selects/select2-bootstrap.css')); ?>">
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/js/select2.min.js"></script>
<script src="<?php echo e(asset('js/auto.js')); ?>"></script>
<script type="text/javascript">

$(document).ready(function() {
  $(".select").select2({
    theme: "bootstrap",
    width:'100%',
     placeholder: "Pilih Member"
   });
});
</script>
<script>
$('#multiselect3-all').multiselect({
    includeSelectAllOption: true,
});
</script>
<script>
var secondClone = $('.second-clone').clone();
secondClone.children('.project-role-first').children().children().addClass('marg-ri');
secondClone.children('.project-role-first').children().children().siblings().removeClass('hidden');
// var projectRole = $('#project-role-first').clone();;

$('#btn-add-member').click(function(){
  let lengthpage = $('#member-page .second-clone').length;
  if(lengthpage == 1){
    let lastItem = $('#member-page .second-clone').last();
    lastItem.children('.project-role-first').children().children().addClass('marg-ri');
    lastItem.children('.project-role-first').children().children().siblings().removeClass('hidden');
  }

  let newclone = member(secondClone.clone());
  $('#member-page').append(newclone.clone());
  $(".select").select2({
    theme: "bootstrap",
    width:'100%',
     placeholder: "Pilih Member"
   });
});

function member(data){
  $('#member-page .second-clone').each(function(){
    let optionSelected = $(this).find('.select option:selected').val();
    data.find('.select option').each(function(){
      if($(this).val() == optionSelected){
        $(this).remove();
      }
    })
  })

  return data;
}

function minus(element){
  let lengthpage = $('#member-page .second-clone').length;
  if(lengthpage == 2){
    element.parents('.second-clone').remove();
    let lastItem = $('#member-page .second-clone').last();
    lastItem.children('.project-role-first').children().children().removeClass('marg-ri');
    lastItem.children('.project-role-first').children().children().siblings('.btn-minus').addClass('hidden');
    console.log(lastItem.children('.project-role-first').children().children().siblings());
  }else {
    element.parents('.second-clone').remove();
  }
};
</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/motekar/resources/views/knowledge/development.blade.php ENDPATH**/ ?>