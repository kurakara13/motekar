<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Motekar</title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', config('app.name')); ?>">
    <meta name="author" content="<?php echo $__env->yieldContent('meta_author', config('app.name')); ?>">
    <?php echo $__env->yieldContent('meta'); ?>

    <?php echo $__env->yieldPushContent('before-styles'); ?>

    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/font-awesome/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/animate-css/vivify.min.css')); ?>">

    <?php echo $__env->yieldPushContent('after-styles'); ?>
    <?php if(trim($__env->yieldContent('page-styles'))): ?>
        <?php echo $__env->yieldContent('page-styles'); ?>
    <?php endif; ?>

    <!-- Custom Css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/site.min.css')); ?>">
    <style type="text/css">
    td {
        white-space: pre-wrap; /* css-3 */
        white-space: -moz-pre-wrap; /* Mozilla, since 1999 */
        white-space: -pre-wrap; /* Opera 4-6 */
        white-space: -o-pre-wrap; /* Opera 7 */
        word-wrap: break-word; /* Internet Explorer 5.5+ */
    }
</style>
</head>

<body class="theme-green font-krub light_version">

<!-- Page Loader -->
<div class="page-loader-wrapper light_version">
    <div class="loader">
        <div class="bar1"></div>
        <div class="bar2"></div>
        <div class="bar3"></div>
        <div class="bar4"></div>
        <div class="bar5"></div>
    </div>
</div>


<!-- Overlay For Sidebars -->
<div class="overlay"></div>

<div id="wrapper">

    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.megamenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.searchbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.rightbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="main-content">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>

<!-- Scripts -->
<?php echo $__env->yieldPushContent('before-scripts'); ?>
<script src="<?php echo e(asset('assets/bundles/libscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/vendorscripts.bundle.js')); ?>"></script>

<?php echo $__env->yieldPushContent('after-scripts'); ?>

<?php if(trim($__env->yieldContent('page-script'))): ?>
    <?php echo $__env->yieldContent('page-script'); ?>
<?php endif; ?>

</body>
</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/motekar/resources/views/layouts/master.blade.php ENDPATH**/ ?>