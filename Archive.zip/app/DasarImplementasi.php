<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DasarImplementasi extends Model
{
    protected $table = 'dasar_implementasi';
}
