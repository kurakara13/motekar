<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SosialisasiImage extends Model
{
    protected $table = 'sosialisasi_image';
    
}
