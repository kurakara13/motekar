<?php $__env->startSection('content'); ?>


<!-- carousel slider -->
<div class="container-fluid">
    <div class="block-header">
        <div class="row clearfix">
            <div class="col-md-6 col-sm-12">
                <h1>Home</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href=""><i class="icon-home"></i></a></li>
                        <li class="breadcrumb-item active">Home</li>
                        <!-- <li class="breadcrumb-item"></li> -->
                        <!-- <li class="breadcrumb-item active"></li> -->
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <div id="app">
      <div class="row clearfix">
        <div class="col-lg-8 col-md-12">
          <div class="x_content bs-example-popovers">
            <div class="slider-item alert-success" >
              <div class="row slider-text align-items-center justify-content-center">
                <div class="col-md-12 ftco-animate text-center">
                  <br>
                  <br>
                  <h4>
                    <span class="fa fa-quote-left"></span>
                    Teruslah kreatif dan berinovasi! Itulah budaya Motekar!
                    <span class="fa fa-quote-right"></span>
                  </h4>
                    <h3>- Mohammad Syibli [GM Telkom Bogor]</h3>
                  <br>
                  <br>
                  <br><br>
                </div>
              </div>
            </div>
          </div>
          <?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mt-3">

                  <div class="body">
                    <h5 class="card-title"><?php echo e($item->sosialisasi->judul); ?></h5>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($item->sosialisasi->created_at); ?></h6>
                    <div class="mb-3">
                      <p><?php echo e($item->sosialisasi->post); ?></p>
                      <?php $__currentLoopData = $item->sosialisasi->image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <img src="<?php echo e(asset('file/doc/'.$image->image)); ?>" style="width:100px" alt="">
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>



                    <div class="card-footer" style="background:#fff; border-color:#e1e8ed" >
                      <div class="row clearfix">
                        <div class="col-md-6">
                          <a href="#" onclick="like('<?php echo e($item->sosialisasi->id); ?>')">Like</a>
                        </div>
                        <div class="col-md-6">
                          <a href="#">Comment</a>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="col-lg-4 col-md-12">
          <div class="card">
            <div class="body">
              <img src="<?php echo e(asset('image/kipas-sakti.png')); ?>" class="card-img-top" alt="">
            </div>
          </div>
          <div class="card">
            <div class="body">
              <div class="d-flex align-items-center">
                    <div class="ml-4">
                        <span>Problem</span>
                        <h4 class="mb-0 font-weight-medium"><?php echo e(count($problem)); ?></h4>
                    </div>
                </div>
            </div>
          </div>
          <div class="card">
            <div class="body">
              <div class="d-flex align-items-center">
                    <div class="ml-4">
                        <span>Project</span>
                        <h4 class="mb-0 font-weight-medium"><?php echo e(count($project)); ?></h4>
                    </div>
                </div>
            </div>
          </div>
        </div>

      </div>

    </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/c3/c3.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/vendor/light-gallery/css/lightgallery.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<script src="<?php echo e(asset('assets/bundles/c3.bundle.js')); ?>"></script>

<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/index.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bundles/lightgallery.bundle.js')); ?>"></script>

<script src="<?php echo e(asset('assets/bundles/mainscripts.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/medias/image-gallery.js')); ?>"></script>
<script type="text/javascript">
  function like(id) {
    var url = "<?php echo e(url('like/')); ?>/"+id;
    console.log(url);
    $.post(url,
    {
      user_id: '<?php echo e(Auth::user()->id); ?>',
    },
    function(data,status){
      alert("Data: " + data + "\nStatus: " + status);
    });
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/motekar/resources/views/home.blade.php ENDPATH**/ ?>